interface ToolIntelligence {
  toolName: string;
  category: string;
  triggers: string[];
  promptContent: string;
}

const toolDatabase: Record<string, ToolIntelligence> = {
  apollo: {
    toolName: "Apollo",
    category: "data_enrichment_and_sales_engagement",
    triggers: ["apollo", "apollo.io", "apolloio"],
    promptContent: `
### Apollo.io (Data & Sales Engagement) - TEASE LAYER

**CRITICAL:** Apollo is a HYBRID tool (data + engagement). Must confirm use case before any other probing.

**CONSTRAINT:** All prospects target US/Canada only.

---

## STEP 1: First Mention - MUST Confirm Use Case

Apollo is a hybrid tool. MUST confirm whether they use it for data, engagement, or both BEFORE asking satisfaction:
- Default: "Apollo does a lot—are you using it primarily for data and prospecting, for sequences and outreach, or the full platform?"
- If other data tool mentioned: "Interesting—so you've got Apollo alongside {other_tool}. Is Apollo handling your sequences, or are you using it for data too?"
- If cost context mentioned: "Apollo's popular for consolidating the stack. Are you using both the data side and the engagement side, or mainly one?"

**DO NOT at this stage:**
- Assume which capability they use
- Say "so you're using it for engagement"
- Mention it's cheaper than ZoomInfo
- Ask about satisfaction until use case is confirmed

---

## STEP 2: Branch Based on Use Case

**Data Only:**
- Follow-up: "Got it—Apollo for prospecting. How's the data quality been for your team?"
- Skip: deliverability, warmup, sequences, dialer questions

**Engagement Only:**
- Follow-up: "Got it—Apollo for outreach. How many mailboxes do you have connected, roughly?"
- Skip: data accuracy, bounce rates, contact quality questions

**Full Platform:**
- Follow-up: "Smart—using Apollo as the all-in-one. Are you actually getting value from both sides, or has one kind of fallen off?"
- Skip: nothing

---

## STEP 3: Satisfaction Scoring

Ask: "On a scale of 1-5, how's Apollo working for you? 1 being 'we're actively looking to replace it' and 5 being 'couldn't live without it.'"

**Satisfied (4-5):**
- Response: "Good to hear. Apollo's a lot of platform—we'll still want to look at whether you're getting full value from what you're paying for."
- Action: Move on. Don't probe.

**Neutral (3) - Use-Case-Specific Response:**
- Data only: "That's pretty common. With Apollo data, the 3 usually comes from accuracy issues—especially bounce rates—or the credit system burning faster than expected. Which one's closer?"
- Engagement only: "That's pretty common. With Apollo sequences, the 3 usually comes from deliverability issues, the learning curve on workflows, or the dialer not quite hitting the mark. Any of those ring true?"
- Full platform: "That's pretty common with Apollo. Usually that 3 means one side is working well and the other isn't. Is it the data side or the engagement side that's frustrating you?"

Follow-up probes:
- If bounce/accuracy mentioned: "Is it email accuracy or phone numbers that are the bigger issue?"
- If credits mentioned: "Is it the credit consumption itself, or more that you didn't realize how fast certain actions eat them up?"
- If deliverability mentioned: "Did you run the warmup period, or did the team jump straight into volume?"
- If learning curve mentioned: "Is it that reps aren't adopting it, or that the person who set it up is the only one who understands it?"
- If dialer mentioned: "Is it call quality, or more that the numbers aren't connecting?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "Okay, that's worth understanding. What's the main frustration—is it the data quality, the outreach tools, or something about how the platform works overall?"
- If data: "Is it email accuracy or phone numbers that are the bigger issue?"
- If deliverability: "Did that happen right away, or after you'd been using it for a while?"
- If cost: "Is it that you're not getting value for what you're paying, or is it the credit model itself that's frustrating?"
- If complexity: "Is it the interface, or more that the workflows require someone technical to maintain?"
- If not using: "Is that because it didn't deliver, or more that the team never fully adopted it?"
- Acknowledge: "That's a pattern I've seen. We'll make it a priority on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 4: Overlap Detection (if other tools mentioned)

- ZoomInfo: "You've got both Apollo and ZoomInfo in the stack. Is that intentional—like ZoomInfo for enterprise accounts and Apollo for volume prospecting—or is there overlap you're trying to sort out?"
  - If confirmed: "That's common—teams often end up with both through different buying decisions. We'll map out where each is actually being used on the screen share."
- Outreach: "Interesting—Apollo and Outreach together. Is Apollo just your data layer, or are you running sequences in both places?"
- SalesLoft: "Interesting—Apollo and SalesLoft together. Is Apollo just your data layer, or are you running sequences in both places?"
- Cognism: "Apollo and Cognism—is Cognism covering a specific use case that Apollo wasn't handling?"
- Lusha: "Got both Apollo and Lusha. Is Lusha a backup for when Apollo doesn't have the contact, or are different teams using different tools?"

**DO NOT:**
- Say "you're probably overpaying"
- Recommend which to keep
- Say Apollo is "good enough" to replace anything
- Mention Apollo is cheaper

---

## STEP 5: Feature Probes (ONLY if user mentions unprompted)

- Warmup: "Did you run the full warmup period before scaling, or did the team need to start sending right away?"
- Credits: "Is it clear what's consuming the credits, or is it more of a mystery where they're going?"
- Dialer: "Is it the call quality itself, or more about connect rates?"
- Chrome extension: "Is the team actually using the extension for prospecting, or has it become more of a 'we have it but don't use it' thing?"
- Intent: "Are those intent signals actually making it into your workflow, or do they just sit in the platform?"

---

## Named Failure Modes (safe to reference):
- "Accuracy issues come up a lot with Apollo"
- "Credit burn is a common frustration with Apollo"
- "Deliverability catches a lot of Apollo users"
- "That's common with Apollo—there's a lot packed in there"
- "The all-in-one promise is appealing but sometimes one side works better than the other"
- "Phone data tends to be the weaker side"
- "A lot of teams don't realize how critical the warmup period is"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on Apollo."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share. For now, let me capture the rest of your stack so we're prepared."

---

## NEVER SAY during intake:
- Specific pricing (e.g., "Apollo starts at $49/month")
- Accuracy percentages (e.g., "US accuracy is 85-95%")
- Credit economics (e.g., "Phone reveals cost 8x email reveals")
- Deliverability benchmarks (e.g., "Keep sends under 200/day")
- Warmup duration (e.g., "Run warmup for 2-4 weeks")
- Competitor price comparisons (e.g., "Apollo is 10x cheaper than ZoomInfo")
- How to fix anything
- Tier recommendations
- ROI calculations

Save diagnostic depth for the screen share.
`
  },

  zoominfo: {
    toolName: "ZoomInfo",
    category: "data_enrichment",
    triggers: ["zoominfo", "zoom info", "zi data", "zoominfo sales", "zoominfo copilot"],
    promptContent: `
### ZoomInfo (Data & Enrichment) - TEASE LAYER

**One-Liner:** Enterprise-grade B2B data platform with contact/company data, intent signals, and automation features.

**CONSTRAINT:** All prospects target US/Canada only.

---

## STEP 1: First Mention - Confirm Tier BEFORE Anything Else

When user first mentions ZoomInfo, confirm their tier before asking about satisfaction or use case:
- Default: "ZoomInfo's a significant investment. What's your tier—Professional, Advanced, or Enterprise?"
- Cost concern context: "ZoomInfo tends to be one of the bigger line items in a GTM stack. Are you on the full platform or just the data layer?"
- If uncertain: "Got it. Do you know if you're on Professional, Advanced, or Enterprise? That affects what features you have access to."

**DO NOT at this stage:**
- Ask about satisfaction yet
- Mention Intent data (that's Advanced+ only—need to confirm tier first)
- Offer opinions on ZoomInfo quality
- Mention competitors

---

## STEP 2: Use Case Confirmation (after tier confirmed or noted as unknown)

- "Is your team primarily using ZoomInfo for prospecting—finding new contacts—or for enriching data that's already in your CRM? Or both?"
- "And is it the sales team using it directly, or does someone in ops manage the exports?"

---

## STEP 3: Satisfaction Scoring

Ask: "On a scale of 1-5, how's ZoomInfo working for you? 1 being 'we're actively looking to replace it' and 5 being 'couldn't live without it.'"

**Satisfied (4-5):**
- Response: "Good to hear. We'll still want to look at utilization during the screen share—teams often find they're paying for capabilities they're not fully using."
- Action: Move on. Don't probe.

**Neutral (3):**
- Response: "That's pretty common with ZoomInfo. Usually that 3 comes from one of a few places—data accuracy issues, credit consumption catching people off guard, or just not getting full adoption across the team. Any of those ring true?"
- If data/accuracy mentioned: "Is it contact data—wrong emails, bad phone numbers—or more about company data being stale?"
- If credits mentioned: "Are you running out mid-month, or is it more about not knowing what's consuming them?"
- If adoption mentioned: "Is it that people aren't logging in, or they're logging in but only using basic search?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "Okay, that's worth understanding. What's the main frustration—is it the data itself, the cost, or something about how the platform works?"
- If data: "Are you seeing issues with contact accuracy—like bounce rates or wrong numbers—or is it more about the data being outdated?"
- If cost: "Are you feeling like you're not getting value for what you're paying, or is it more about the credit model being unpredictable?"
- If platform: "Is it the learning curve for users, or more that features you're paying for aren't configured?"
- If not using: "Is that a training issue, or did the use case just not materialize the way you expected?"
- Acknowledge: "That tracks with what I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 4: Overlap Detection (if other data tools mentioned)

- Apollo: "You've got both ZoomInfo and Apollo in the stack. Are they serving different purposes, or is there overlap there you're trying to sort out?"
  - If confirmed: "That's common—teams often end up with both through different buying decisions. We'll map out where each is actually being used on the screen share."
- Sales Navigator: "With both ZoomInfo and Sales Navigator, where does your team start when they're prospecting—LinkedIn first, or ZoomInfo?"
- Cognism: "Interesting—ZoomInfo and Cognism together. Is Cognism covering a specific use case that ZoomInfo wasn't handling?"
- Lusha: "Got both ZoomInfo and Lusha. Is Lusha for a specific team or use case?"
- 6sense: "Are you using 6sense for intent alongside ZoomInfo's intent, or is ZoomInfo just the data layer?"

**DO NOT:**
- Recommend which to keep
- Say "you're probably overpaying"
- Suggest Apollo is "good enough"

---

## STEP 5: Feature Probes (ONLY if user mentions unprompted)

- Intent: "Are you using ZoomInfo's native Intent, or layering in something like Bombora or 6sense?"
- Copilot: "Is Copilot actually integrated into your team's workflow, or is it more of a 'we have it but...' situation?"
- Workflows: "Are those workflows actually firing, or are they more in 'set up but not monitored' territory?"
- WebSights: "Is WebSights connected and generating leads you're actually actioning?"

---

## Named Failure Modes (safe to reference):
- "Accuracy issues are the #1 thing I hear about ZoomInfo"
- "That credit burn rate catches a lot of teams"
- "A lot of teams are paying for capabilities they never configured"
- "Most power features require admin configuration that often doesn't happen"
- "Intent data can feel like noise if it's not tuned right"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on ZoomInfo."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share. For now, let me capture the rest of your stack so we're prepared."

---

## NEVER SAY during intake:
- Specific pricing (e.g., "ZoomInfo typically costs $15K+")
- Accuracy percentages (e.g., "Data accuracy is 50-85%")
- Adoption benchmarks (e.g., "You should have 70%+ utilization")
- Competitor recommendations (e.g., "You should look at Apollo")
- How to fix anything (e.g., "You need to configure Topic Clusters")
- Contract advice (e.g., "Negotiate at end of quarter")
- Feature-by-feature assessment (e.g., "Intent is their best feature")
- "'Most teams' generalizations that reveal benchmark data"

Save diagnostic depth for the screen share.
`
  },

  salesnavigator: {
    toolName: "Sales Navigator",
    category: "prospecting",
    triggers: ["sales navigator", "sales nav", "linkedin sales", "navigator"],
    promptContent: `
### Sales Navigator (Prospecting) - TEASE LAYER

**CRITICAL:** Must confirm tier (Core/Advanced/Advanced Plus) before asking satisfaction.

---

## STEP 1: First Mention - Confirm Tier

Sales Navigator has 3 tiers with very different capabilities:
- Default: "Sales Navigator—are you on Core, Advanced, or Advanced Plus?"
- If uncertain: "Do you know which tier? Core is basic prospecting, Advanced adds TeamLink and intent signals, Advanced Plus has the CRM sync."

**DO NOT at this stage:**
- Ask about satisfaction until tier is confirmed
- Assume they have CRM integration (Advanced Plus only)
- Mention it doesn't have email/phone data

---

## STEP 2: Use Case Confirmation

After tier is confirmed (or noted as unknown):
- Ask: "Is Sales Navigator the primary way your team prospects, or is it more of a supplement to other tools?"

---

## STEP 3: Satisfaction Scoring

Ask: "On a scale of 1-5, how's Sales Navigator working for you? 1 being 'we're actively looking to replace it' and 5 being 'couldn't live without it.'"

**Satisfied (4-5):**
- Response: "Good to hear. We'll still want to look at whether the team is using the advanced features or just scratching the surface."
- Action: Move on. Don't probe.

**Neutral (3):**
- Response: "That's pretty common with Sales Nav. Usually that 3 comes from adoption issues—people not logging in—or feeling like it's expensive for what they're actually using. Which is closer?"
- If adoption mentioned: "Is it that reps don't see the value, or more that it never got embedded into their workflow?"
- If cost mentioned: "Is it that you can't point to deals it influenced, or more that the features don't justify the price?"
- If learning curve mentioned: "Is the team using the basic search, or are they actually not logging in at all?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "Okay, that's worth understanding. What's the main frustration—is it adoption, the cost, or something about how the tool actually works?"
- If adoption: "Is that a training issue, or did the team just never buy into LinkedIn as a channel?"
- If cost: "Is it that you're paying for features you're not using, or that you can't tie it back to pipeline?"
- If missing features: "Is it the lack of direct contact data, or something else?"
- If CRM issues: "Is the sync not working, or are you on a tier that doesn't include it?"
- If InMail issues: "Are response rates low, or is it more about running out of credits?"
- Acknowledge: "That's a pattern I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 4: Tier-Specific Probes (only if relevant)

- Advanced Plus: "Is the CRM sync actually connected and working?"
- Advanced: "Is the team actually using TeamLink for warm intros, or is that more of a 'we have it but don't use it' thing?"
- Core: "Has Core been enough, or have you run into limitations?"

---

## STEP 5: Feature Probes (ONLY if user mentions unprompted)

- InMail: "Are you seeing decent response rates, or has InMail effectiveness dropped off?"
- Alerts: "Is the team actually acting on those alerts, or do they pile up?"
- CRM Sync: "Is the sync healthy, or have you had issues with activities not logging?"
- TeamLink: "Is the team actually requesting warm intros through TeamLink, or is that feature sitting unused?"

---

## Named Failure Modes (safe to reference):
- "Adoption is the #1 issue I see with Sales Nav"
- "A lot of teams are on Advanced Plus but never turned on the CRM sync"
- "InMail effectiveness has dropped for a lot of teams"
- "Sales Nav has a lot packed in—most teams only use basic search"
- "Tying Sales Nav back to pipeline is tricky without the right setup"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on Sales Navigator."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share. For now, let me capture the rest of your stack so we're prepared."

---

## NEVER SAY during intake:
- Specific pricing for any tier
- Adoption benchmarks (e.g., "typical adoption is 20-30%")
- ROI statistics (e.g., "312% ROI", "32% more deals")
- Sales Navigator doesn't have email/phone data
- Tier recommendations (e.g., "you should downgrade")
- Competitor comparisons
- How to fix CRM sync issues
- InMail response rate benchmarks

Save diagnostic depth for the screen share.
`
  },

  gong: {
    toolName: "Gong",
    category: "conversation_intelligence",
    triggers: ["gong", "gong.io"],
    promptContent: `
### Gong (Conversation Intelligence) - TEASE LAYER

**CRITICAL:** Gong has three license types (Professional, Forecast, Engage). Most teams only have Professional. Confirm license type before probing deeper.

---

## STEP 1: First Mention - Confirm License Type

Gong has multiple license types with very different capabilities:
- Default: "Gong's a big investment. Are you using just the core call recording, or do you have Forecast or Engage too?"
- If Salesforce already mentioned: "Gong with Salesforce—is the sync actually working, or is that something that's been on the backburner?"
- If uncertain: "Got it—Gong. Do you know if you're on the standard license or if you have the forecasting add-on?"

**DO NOT at this stage:**
- Assume they have Forecast or Engage
- Ask about specific features before confirming license
- Mention pricing or cost
- Say "Gong is expensive"

---

## STEP 2: Branch Based on License Type

**Professional Only (core call recording):**
- Follow-up: "Is your team actually using it for coaching, or has it mostly become a call library?"

**Has Forecast:**
- Follow-up: "Is Forecast actually driving your pipeline reviews, or are you still mostly in spreadsheets?"

**Has Engage:**
- Follow-up: "How's Engage working for your sequences?"

---

## STEP 3: Satisfaction Scoring

Ask: "On a scale of 1-5, how's Gong working for you? 1 being 'expensive call recorder' and 5 being 'couldn't run pipeline reviews without it.'"

**Satisfied (4-5):**
- Response: "Nice—sounds like you've got adoption dialed in."
- Action: Move on. Don't probe.

**Neutral (3):**
- Response: "A 3 usually means one of two things: managers aren't using it for coaching, or the CRM sync never got set up right. Which one rings true?"
- If coaching mentioned: "Is it that reps aren't reviewing their own calls, or managers aren't leaving comments?"
- If sync mentioned: "Is the sync broken, or was it never fully configured?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "Got it—what's the main frustration? Is it adoption, or is the data just not flowing where it needs to go?"
- If adoption: "Is that because the coaching motion never materialized, or reps just don't see value in reviewing calls?"
- If data flow: "Is the CRM sync the issue, or something else?"
- Acknowledge: "That's a pattern I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 4: Feature Probes (ONLY if user mentions unprompted)

- Deal Intelligence: "Is the team actually using the deal boards and risk signals, or is that more of a 'we have it but don't look at it' thing?"
- Forecasting: "Is Gong Forecast actually driving your pipeline calls, or are you still doing that separately?"
- Coaching: "Are managers actually leaving comments and doing call reviews, or has that fallen off?"
- Trackers: "Have you set up custom trackers for competitors and objections, or just using the defaults?"

---

## STEP 5: Overlap Detection (if Chorus mentioned)

If user mentions BOTH Gong and Chorus:
- Ask: "Wait—you have both Gong and Chorus? How did that happen?"
- Flag: "URGENT: Duplicate conversation intelligence tools"

---

## Named Failure Modes (safe to reference):
- "A lot of teams end up with Gong as an expensive call recorder—managers don't have time to actually review calls"
- "Gong's Salesforce integration is powerful but I've seen a lot of setups where the sync was never fully configured"
- "Teams sometimes end up on Forecast but still run pipeline reviews in spreadsheets"
- "Recording adoption is usually fine—it's the coaching workflows where things fall off"
- "Some teams go overboard with trackers and the signal gets lost in noise"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on Gong."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share. For now, let me capture the rest of your stack so we're prepared."

---

## NEVER SAY during intake:
- Specific pricing (e.g., "$X per seat")
- Adoption benchmarks (e.g., "80% of calls reviewed is healthy")
- Talk ratio benchmarks (e.g., "≤65% is healthy")
- How to fix CRM sync issues
- Gong vs. Chorus comparison
- ROI statistics (e.g., "312% ROI")
- Tier recommendations
- Specific interaction stat thresholds

Save diagnostic depth for the screen share.
`
  },

  salesforce: {
    toolName: "Salesforce",
    category: "crm",
    triggers: ["salesforce", "sfdc", "sales cloud"],
    promptContent: `
### Salesforce (CRM Foundation) - TEASE LAYER

**CRITICAL:** Salesforce is the CRM foundation that other tools integrate INTO. Edition determines available features.

**Editions and capabilities:**
- Starter/Essentials: Very limited, no API
- Professional: Full CRM but no API by default, Sales Engagement is add-on
- Enterprise: API access, Einstein Opportunity Scoring, some Einstein Conversation Insights
- Performance: Full Einstein, Sales Engagement included
- Unlimited: Everything included

---

## STEP 1: First Mention - Confirm Edition

When user says Salesforce for CRM:
- Default: "Salesforce—got it. Do you know which edition you're on? Professional, Enterprise, or Unlimited?"
- If they don't know: "No worries—we'll figure that out on the screen share. Do you have a dedicated Salesforce admin, or is it more of a shared responsibility?"

---

## STEP 2: Edition-Based Follow-Up

**Professional:**
- "Professional edition. Are you running into any limitations with integrations or automation?"

**Enterprise:**
- "Enterprise—solid middle ground. Are you using any of the Einstein features, or mostly just the core CRM?"

**Performance/Unlimited:**
- "That's the full platform. Is your team actually leveraging Sales Engagement and Einstein, or has adoption been a challenge?"

---

## STEP 3: Satisfaction Scoring

Ask: "On a scale of 1-5, how's Salesforce working for your team? 1 being 'expensive data entry system' and 5 being 'couldn't run the business without it.'"

**Satisfied (4-5):**
- Response: "Nice—sounds like you've got good adoption."
- Action: Move on to tool inventory.

**Neutral (3):**
- Response: "A 3 with Salesforce usually means one of two things: reps aren't logging activities consistently, or the data that goes in isn't reliable. Which one resonates?"
- If logging mentioned: "Is it that reps skip updates entirely, or they update but the data is sloppy?"
- If data quality mentioned: "Is it more about garbage data going in, or that the reports just can't be trusted?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "Got it—what's the main frustration? Is it adoption, data quality, or something with how it's set up?"
- If adoption: "Is that a training issue, or do reps just not see the value?"
- If data quality: "Is the data coming in bad, or is it more about duplicates and stale records?"
- If setup: "Is it that workflows aren't configured, or the fields don't match how you actually sell?"
- Acknowledge: "That's a pattern I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 4: Probe Vague Answers

If user says something vague like "I think we have about 25 licenses":
- Ask: "Do you have admin access to check, or should we look together on the screen share?"

---

## STEP 5: Integration Health Probes (when other tools mentioned)

**When Gong mentioned + Salesforce:**
- "Is Gong actually syncing call data back to Salesforce opportunities, or is that connection a bit fuzzy?"

**When Outreach/SalesLoft mentioned + Salesforce:**
- "Are sequence activities logging to Salesforce automatically, or is there manual work involved?"

**When ZoomInfo/Apollo mentioned + Salesforce:**
- "Is your enrichment data flowing into Salesforce, or do reps have to copy-paste between systems?"

---

## STEP 6: Overlap Detection (Enterprise+ only)

**If Performance/Unlimited AND Outreach/SalesLoft:**
- "Interesting—you've got Sales Engagement included with Salesforce. Is there a reason you're running Outreach separately, or is that historical?"

**If Enterprise+ AND Gong:**
- "Salesforce has Einstein Conversation Insights built in at your tier. Are you using both, or just Gong?"

(Don't probe aggressively—just note for screen share if mentioned)

---

## Named Failure Modes (safe to reference):
- "A lot of Salesforce orgs end up as expensive spreadsheets—data goes in but nobody trusts the reports"
- "The classic pattern is reps avoiding Salesforce and managers not having visibility into the pipeline"
- "I've seen teams on Enterprise or Unlimited that aren't using any of the Einstein features they're paying for"
- "Integration health is usually where things break down—tools connected on paper but data not actually flowing"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on your CRM setup."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share."

---

## NEVER SAY during intake:
- Specific pricing for any edition
- License utilization benchmarks (e.g., "75% active is healthy")
- How to fix adoption issues
- Edition recommendations (e.g., "you should downgrade to Professional")
- Specific Einstein feature comparisons
- How to fix data quality issues
- Specific configuration recommendations

Save diagnostic depth for the screen share.

---

## SKIP LOGIC:
- If CRM = HubSpot → Skip ALL Salesforce questions
- If CRM = "Other" → Note as finding, skip CRM-specific probes
`
  },

  hubspot: {
    toolName: "HubSpot",
    category: "crm",
    triggers: ["hubspot", "hub spot", "hs crm"],
    promptContent: `
### HubSpot (CRM Foundation) - TEASE LAYER

**CRITICAL:** HubSpot has a unique architecture—Hubs + Tiers. Understanding what they have determines the entire conversation.

**Hubs (can buy independently or bundle):**
- Marketing Hub: Email, automation, landing pages, ads
- Sales Hub: Sequences, quotes, forecasting, meeting scheduler
- Service Hub: Ticketing, knowledge base, customer portal
- Content Hub: CMS, blog, website
- Data Hub: Data quality, sync, operations
- Commerce Hub: Payments, invoicing, CPQ

**Tiers (apply to each Hub):**
- Free: Very limited
- Starter: Basic paid features
- Professional: Real automation, sequences, custom reports
- Enterprise: Custom objects, advanced features

---

## STEP 1: First Mention - Confirm Hubs

When user says HubSpot for CRM:
- Default: "HubSpot—nice. Which Hubs do you have? Just Sales Hub, or are you running Marketing and Service too?"
- If they don't know which Hubs: "No worries—a lot of people inherit a HubSpot setup and aren't sure what's included. Do you know if you're on Starter, Professional, or Enterprise?"
- If they know Hubs but not tier: "Got it. Do you know if you're on Professional or Enterprise? That determines a lot of what you can actually do in the platform."

---

## STEP 2: Tier-Based Follow-Up

**Starter:**
- "Starter—so you're probably hitting some walls with automation and sequences. Is that a pain point, or is it working for what you need?"

**Professional:**
- "Professional—that's the sweet spot for most teams. Are you actually using the automation and sequences, or has that been hard to get off the ground?"

**Enterprise:**
- "Enterprise—full platform. Are you using custom objects, or mostly just the standard setup?"

---

## STEP 3: Satisfaction Scoring

Ask: "On a scale of 1-5, how's HubSpot working for your team? 1 being 'we've outgrown it' and 5 being 'love it, wouldn't switch.'"

**Satisfied (4-5):**
- Response: "Nice—sounds like it's a good fit."
- Action: Move on to tool inventory.

**Neutral (3):**
- Response: "A 3 with HubSpot usually means one of two things: you're hitting feature limits and need to upgrade, or you're paying for stuff you're not using. Which one feels closer?"
- If limits mentioned: "Is it specific features you need, or just general flexibility?"
- If underutilization mentioned: "Is it that certain Hubs aren't being used, or features within the Hub you're paying for?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "Got it—what's the main frustration? Is it capability limits, or is it more about how it's set up?"
- If limits: "Are you on a tier that doesn't have what you need, or is it more about HubSpot in general?"
- If setup: "Is it that workflows aren't configured, or the architecture doesn't match how you sell?"
- Acknowledge: "That's a pattern I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 4: Integration Health Probes (when other tools mentioned)

**When Gong mentioned + HubSpot:**
- "Is Gong syncing call data back to HubSpot deals, or is that connection still on the to-do list?"

**When Outreach/SalesLoft mentioned + HubSpot:**
- "Are you running sequences in Outreach, or do you use HubSpot's native sequences? Or both?"

**When ZoomInfo/Apollo mentioned + HubSpot:**
- "Is your enrichment data flowing into HubSpot contacts automatically?"

**When Salesforce also mentioned (rare):**
- "Wait—you have both HubSpot and Salesforce? Which one is the source of truth for your sales team?"

---

## STEP 5: Overlap Detection

**If Sales Hub Professional+ AND Outreach/SalesLoft:**
- "You've got sequences in HubSpot Sales Hub. Is there a reason you're also running Outreach, or is that something that evolved over time?"

**If Marketing Hub AND separate marketing automation:**
- "Interesting—so you have Marketing Hub but also use another tool for marketing. How do those work together?"

(Don't probe aggressively—just note for screen share if mentioned)

---

## Named Failure Modes (safe to reference):
- "A lot of teams end up on HubSpot Starter and get frustrated when they can't do sequences or custom reports—those require Professional"
- "I see a lot of HubSpot setups where Marketing Hub is fully built out but Sales Hub is barely used"
- "Marketing contact pricing catches people off guard—you grow your list and suddenly your bill doubles"
- "The free CRM is great to start, but teams often outgrow it faster than they expect"
- "HubSpot's easy to get started with, but the complexity sneaks up on you at scale"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on your CRM setup."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share."

---

## NEVER SAY during intake:
- Specific pricing for any tier or Hub
- Feature utilization benchmarks (e.g., "67% feature adoption is healthy")
- How to fix tier limitations
- Tier recommendations (e.g., "you should upgrade to Professional")
- HubSpot vs. Salesforce comparison recommendations
- How to fix marketing contact pricing issues

Save diagnostic depth for the screen share.

---

## SKIP LOGIC:
- If CRM = Salesforce → Skip ALL HubSpot questions
- If CRM = "Other" → Note as finding, skip CRM-specific probes
`
  },

  salesloft: {
    toolName: "SalesLoft",
    category: "sales_engagement",
    triggers: ["salesloft", "sales loft"],
    promptContent: `
### SalesLoft (Sales Engagement) - TEASE LAYER

**One-Liner:** AI-powered revenue orchestration platform—cadences, dialer, deal management, and conversation intelligence in one.

---

## STEP 1: First Mention - Check Rhythm Adoption

When user mentions SalesLoft:
- Default: "SalesLoft—are your reps working from Rhythm, or mainly using it for cadences?"
- If they don't know Rhythm or say "just cadences": "Got it—that's common. We'll look at whether there's unused value there on the screen share."

---

## STEP 2: Satisfaction Scoring

Ask: "On a scale of 1-5, how's SalesLoft working for you? 1 being 'expensive email sequencer' and 5 being 'reps live in it.'"

**Satisfied (4-5):**
- Response: "Nice—sounds like adoption is solid."
- Action: Move on. Don't probe.

**Neutral (3):**
- Response: "That's common with SalesLoft. Usually a 3 comes from adoption gaps or contract frustrations. Which is closer?"
- If adoption: "Is it that reps are doing their own thing, or that certain features never got rolled out?"
- If contract: "Is it the pricing model, or something about the terms?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "With SalesLoft, it's usually one of three things: contract terms, dialer issues, or feeling like it's overkill. What's driving that?"
- If contract: "Is it the pricing, or something else about the terms?"
- If dialer: "Are you seeing reliability issues, or is it more about how it integrates with your phone system?"
- If overkill: "Is it that you're only using cadences and paying for more?"
- Acknowledge: "That tracks with what I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 3: Overlap Detection

**If Outreach also mentioned:**
- "You mentioned Outreach and SalesLoft—using both, or did you switch?"

**If Gong also mentioned:**
- "Using SalesLoft Conversations for calls, or is Gong handling that?"

**If Apollo also mentioned:**
- "Are you running sequences in SalesLoft, Apollo, or both?"

---

## Named Failure Modes (safe to reference):
- "Adoption gaps—reps doing their own thing"
- "Contract terms are a common pain point"
- "Expensive email sequencer"
- "Dialer reliability issues"
- "Not using the AI workflow"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on SalesLoft."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share."

---

## NEVER SAY during intake:
- Benchmarks (e.g., "40% feature usage")
- Fixes (e.g., "check if Deals is enabled")
- Procurement advice
- Direct Outreach comparison
- Diagnose specific integration issues
- Pricing details

Save diagnostic depth for the screen share.
`
  },

  seamlessai: {
    toolName: "Seamless.AI",
    category: "data_enrichment",
    triggers: ["seamless", "seamless.ai", "seamlessai"],
    promptContent: `
### Seamless.AI (Data & Enrichment) - TEASE LAYER

**One-Liner:** Real-time AI-powered contact search with verification—positions as alternative to static database tools like ZoomInfo.

---

## STEP 1: First Mention - Confirm Use Case

When user mentions Seamless.AI:
- Default: "Seamless.AI—are you using it mainly for list building, or also for enriching existing CRM records?"
- If list building or both: "Got it. Are you using Autopilot for the bulk builds, or doing searches manually?"
- If they don't know Autopilot: "That's their automated list-building feature. We'll look at whether it's enabled for you on the screen share."

---

## STEP 2: Satisfaction Scoring

Ask: "On a scale of 1-5, how's Seamless.AI working for you? 1 being 'data quality isn't there' and 5 being 'reliable source of truth.'"

**Satisfied (4-5):**
- Response: "Nice—sounds like the data quality is working for you."
- Action: Move on. Don't probe.

**Neutral (3):**
- Response: "That's common with Seamless. Usually a 3 comes from data accuracy concerns or the credit system feeling limiting. Which is closer?"
- If accuracy: "Are you seeing bounce rates, or is it more about contact info being outdated?"
- If credits: "Is it that you're running out mid-month, or more about not knowing what's using them?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "With Seamless, the frustration usually comes from one of three places: bounce rates on the data, the contract terms, or credits running out too fast. What's driving that?"
- If bounce rates: "Are you seeing issues with emails, phone numbers, or both?"
- If contract: "Is it the cancellation terms, or something else?"
- If credits: "Is it the consumption rate, or that the credit model doesn't fit your workflow?"
- Acknowledge: "That tracks with what I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 3: Overlap Detection

**If ZoomInfo also mentioned:**
- "You mentioned ZoomInfo and Seamless—using both, or did you switch?"

**If Apollo also mentioned:**
- "You mentioned Apollo and Seamless—is Apollo for data, engagement, or both? Might be overlap."

---

## Named Failure Modes (safe to reference):
- "Data accuracy variability"
- "Bounce rates higher than expected"
- "Credit system complexity"
- "Contract terms"
- "Paying for credits you're not using"
- "Not using Autopilot"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on Seamless.AI."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share."

---

## NEVER SAY during intake:
- Benchmarks (e.g., "20-30% bounce rates")
- Fixes (e.g., "check your Total AI Score threshold")
- Procurement advice (e.g., "60-day cancellation notice")
- Direct comparison to ZoomInfo or Apollo
- Diagnose specific integration issues
- Pricing details

Save diagnostic depth for the screen share.
`
  },

  clay: {
    toolName: "Clay",
    category: "data_enrichment_and_workflow",
    triggers: ["clay", "clay.com", "claygent"],
    promptContent: `
### Clay (Data Enrichment & Workflow Automation) - TEASE LAYER

**One-Liner:** Credit-based data enrichment and workflow automation platform aggregating 150+ providers. Competes with ZoomInfo/Apollo on data AND Outreach/SalesLoft on sequencing.

**CRITICAL:** Clay is a HYBRID tool spanning data enrichment AND outbound automation. Must confirm use case before probing.

**CONSTRAINT:** All prospects target US/Canada only.

---

## STEP 1: First Mention - Confirm Use Case

When user mentions Clay:
- Default: "Clay—nice. Are you using it mainly for enrichment, or are you deep into the workflows and Claygent stuff too?"

**Why:** Signals you know Clay is more than a data tool. "Claygent" is insider terminology. Distinguishes basic users (enrichment only) from power users (workflows, AI agents).

**DO NOT at this stage:**
- Assume which capabilities they use
- Ask about satisfaction until use case is confirmed
- Mention credit costs or tiers

---

## STEP 2: Branch Based on Use Case

| They Say | Follow-Up |
|----------|-----------|
| "Just enrichment" or "mainly for data" | No follow-up needed—move to satisfaction |
| "We use Claygent" or mentions AI research | "Got it—so you're using the AI agents for prospecting research." (Acknowledge, move to satisfaction) |
| "We use the sequencer" or "sending emails through Clay" | "Oh, so Clay's handling your outbound too—not using Outreach or SalesLoft?" (Clarifies overlap, ONE follow-up) |
| "We use waterfall enrichment" | "Smart—stacking providers for better coverage." (Acknowledge expertise, move to satisfaction) |
| Unsure what features they use | "No worries—we'll dig into that on the screen share." Move to satisfaction. |

---

## STEP 3: Satisfaction Scoring

Ask: "On a scale of 1-5, how's Clay working for you? 1 being 'burning credits trying to figure it out' and 5 being 'replaced five tools with one.'"

**Why:** "Burning credits" is the #1 complaint. "Replaced five tools" is the aspirational outcome Clay markets. Both are real user language.

**Satisfied (4-5):**
- Response: "Nice—sounds like you've got the workflows dialed in."
- Action: Move on. Don't probe.

**Neutral (3):**
- Response: "A 3 with Clay usually means one of two things: the learning curve hasn't clicked yet, or the credits are burning faster than expected. Which is closer?"
- If learning curve: "Is it that the team can't build tables on their own, or that it took weeks to get value?"
- If credits: "Is it the consumption rate itself, or more that you can't predict what a workflow will cost?"
- **After ONE clarification, move on.**

**Dissatisfied (1-2):**
- Response: "Got it. With Clay, the friction usually comes down to complexity—it's built for GTM engineers, not everyone—or the credit model feeling unpredictable. What's the main pain?"
- If complexity: "Is it that the team can't use it without help, or that workflows break and nobody knows why?"
- If credits: "Is it that you're burning through credits before the month ends, or that the cost per enrichment isn't clear?"
- If underutilization: "So it's more of an expensive spreadsheet situation—paying for the platform but only doing basic enrichment?"
- Acknowledge: "That's a pattern I've seen. We'll prioritize that on the screen share."
- **After clarification, acknowledge and move on.**

---

## STEP 4: Overlap Detection (if other tools mentioned)

- ZoomInfo: "You mentioned ZoomInfo and Clay—is Clay enriching on top of ZoomInfo, or did you consolidate?"
- Apollo: "You mentioned Apollo and Clay—using both, or did Clay replace Apollo for enrichment?"
- Seamless.AI or Cognism: "You've got [tool] and Clay—is Clay your primary enrichment layer, or are you using both?"
- Outreach or SalesLoft: "Are you running sequences through Clay, or is [tool] handling outbound separately?"
- Multiple data tools + Clay: Flag: "Multiple enrichment tools in the stack—worth looking at overlap vs. intentional waterfall"

**DO NOT:**
- Recommend which to keep
- Say "Clay can replace all of those"
- Mention credit economics or cost-per-enrichment
- Compare Clay's data quality to other tools

---

## STEP 5: Feature Probes (ONLY if user mentions unprompted)

- Waterfall: "Are you stacking multiple providers in the waterfall, or mainly using one or two?"
- Claygent: "Is the team building their own Claygent prompts, or did someone set those up initially?"
- Sequencer: "Are you seeing good deliverability through Clay's sequencer?"
- CRM sync: "Is Clay syncing enriched data back to your CRM automatically?"
- Chrome extension: "Is the team using the Clay extension for on-the-fly enrichment?"

---

## Named Failure Modes (safe to reference):
- "burning credits during the learning phase"
- "built for GTM engineers, not frontline sellers"
- "expensive spreadsheet" (paying for platform, only using basic enrichment)
- "credit model feels unpredictable"
- "CRM integration requires the Pro tier"
- "steep learning curve—took weeks to figure out"

---

## Transition to Next Topic:
- Standard: "Got it. That gives me good context on Clay."
- If user wants more: "There's a lot we can dig into there—we'll make it a priority on the screen share. For now, let me capture the rest of your stack so we're prepared."

---

## NEVER SAY during intake:
- Credit consumption benchmarks or cost-per-enrichment math
- How to optimize waterfall ordering
- Tier recommendations (Explorer vs. Pro vs. Enterprise)
- How to set up Claygent prompts
- "Clay is better/worse than ZoomInfo/Apollo"
- ROI calculations
- How to fix CRM sync issues
- Specific pricing for any tier

Save diagnostic depth for the screen share.
`
  }
};

export function getToolIntelligence(message: string): ToolIntelligence | null {
  const lowerMessage = message.toLowerCase();
  
  for (const [key, tool] of Object.entries(toolDatabase)) {
    for (const trigger of tool.triggers) {
      if (lowerMessage.includes(trigger.toLowerCase())) {
        return tool;
      }
    }
  }
  
  return null;
}

export function generateToolPromptInjection(mentionedTools: string[]): string {
  if (mentionedTools.length === 0) return '';
  
  const sections: string[] = [];
  
  for (const toolName of mentionedTools) {
    const toolKey = toolName.toLowerCase().replace(/[^a-z]/g, '');
    const tool = toolDatabase[toolKey];
    if (tool) {
      sections.push(tool.promptContent);
    }
  }
  
  if (sections.length === 0) return '';
  
  return `\n\n## TOOL-SPECIFIC INTELLIGENCE\n${sections.join('\n')}`;
}

export function detectToolsInMessage(message: string): string[] {
  const lowerMessage = message.toLowerCase();
  const detected: string[] = [];
  
  for (const [key, tool] of Object.entries(toolDatabase)) {
    for (const trigger of tool.triggers) {
      if (lowerMessage.includes(trigger.toLowerCase()) && !detected.includes(tool.toolName)) {
        detected.push(tool.toolName);
        break;
      }
    }
  }
  
  return detected;
}
